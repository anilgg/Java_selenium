package common.uimap;

public class UIMap {
	public static String toolbar =  ".//*[@id='menuButton_2']";
	public static String notePanel = "//div[@id='fnd_ias_cnfgPnl_1']";
	public static String noteTextArea ="//textarea[@name='noteInput']";
	public static String addnotesbutton = "//button[@name='Create']";
	
}
